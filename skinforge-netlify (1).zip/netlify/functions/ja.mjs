// /api/ja – mówi stronie, kto jest zalogowany.
import { odczytaj } from '../lib/sesja.mjs';

const json = (o, status = 200) => new Response(JSON.stringify(o), {
  status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }
});

export default async (req) => {
  try {
    const u = odczytaj(req);
    if (!u) return json({ zalogowany: false });
    return json({
      zalogowany: true, id: u.id, nick: u.nick, awatar: u.awatar,
      profil: 'https://steamcommunity.com/profiles/' + u.id
    });
  } catch (e) {
    return json({ zalogowany: false, blad: e.message }, 500);
  }
};

export const config = { path: '/api/ja' };
