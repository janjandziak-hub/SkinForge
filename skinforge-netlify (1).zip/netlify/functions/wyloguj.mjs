// /api/wyloguj – usuwa ciasteczko sesji i wraca na stronę główną.
import { ciasteczko, przekieruj } from '../lib/sesja.mjs';

export default async () => przekieruj('/', ciasteczko('', 0));

export const config = { path: '/api/wyloguj' };
