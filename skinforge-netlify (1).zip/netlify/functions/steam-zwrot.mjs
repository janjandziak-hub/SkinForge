// /api/steam-zwrot – Steam wraca tutaj po zalogowaniu.
// Potwierdzamy odpowiedź bezpośrednio u Steama, pobieramy nick i awatar
// z publicznego profilu i zapisujemy podpisane ciasteczko sesji.
import { utworz, ciasteczko, przekieruj, DNI } from '../lib/sesja.mjs';

function cdata(xml, tag) {
  const m = xml.match(new RegExp('<' + tag + '><!\\[CDATA\\[([\\s\\S]*?)\\]\\]></' + tag + '>'));
  return m ? m[1] : '';
}

export default async (req) => {
  try {
    const url = new URL(req.url);
    const q = url.searchParams;
    const strona = url.origin;

    if (q.get('openid.mode') !== 'id_res') return przekieruj('/zamowienie.html?logowanie=anulowane');
    if (!(q.get('openid.return_to') || '').startsWith(strona + '/api/steam-zwrot')) throw new Error('Zły adres powrotu');
    if (q.get('openid.op_endpoint') !== 'https://steamcommunity.com/openid/login') throw new Error('Zły dostawca logowania');

    const m = (q.get('openid.claimed_id') || '').match(/^https:\/\/steamcommunity\.com\/openid\/id\/(\d{17})$/);
    if (!m) throw new Error('Brak identyfikatora Steam');
    const steamId = m[1];

    // Sprawdzenie u Steama, że odpowiedź jest prawdziwa
    const spr = new URLSearchParams();
    for (const [k, v] of q) if (k.startsWith('openid.')) spr.set(k, v);
    spr.set('openid.mode', 'check_authentication');
    const r = await fetch('https://steamcommunity.com/openid/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: spr.toString()
    });
    const tekst = await r.text();
    if (!/is_valid\s*:\s*true/.test(tekst)) throw new Error('Steam nie potwierdził logowania');

    // Nick i awatar z publicznego profilu (bez klucza API)
    let nick = '', awatar = '';
    try {
      const p = await fetch('https://steamcommunity.com/profiles/' + steamId + '/?xml=1');
      const xml = await p.text();
      nick = cdata(xml, 'steamID');
      awatar = cdata(xml, 'avatarMedium');
    } catch (e) { /* profil prywatny lub niedostępny – zostaje sam SteamID */ }

    const sesja = utworz({ id: steamId, nick: nick || 'Gracz ' + steamId.slice(-4), awatar });
    return przekieruj('/zamowienie.html?logowanie=ok', ciasteczko(sesja, DNI * 86400));
  } catch (e) {
    console.error('Logowanie Steam:', e.message);
    return przekieruj('/zamowienie.html?logowanie=blad');
  }
};

export const config = { path: '/api/steam-zwrot' };
