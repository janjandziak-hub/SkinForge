// /api/login – przekierowuje gracza na stronę logowania Steam.
import { przekieruj } from '../lib/sesja.mjs';

export default async (req) => {
  const strona = new URL(req.url).origin;
  const p = new URLSearchParams({
    'openid.ns': 'http://specs.openid.net/auth/2.0',
    'openid.mode': 'checkid_setup',
    'openid.return_to': strona + '/api/steam-zwrot',
    'openid.realm': strona + '/',
    'openid.identity': 'http://specs.openid.net/auth/2.0/identifier_select',
    'openid.claimed_id': 'http://specs.openid.net/auth/2.0/identifier_select'
  });
  return przekieruj('https://steamcommunity.com/openid/login?' + p.toString());
};

export const config = { path: '/api/login' };
