// /api/discord-start?tryb=logowanie|polacz&wroc=/sciezka – przekierowanie na logowanie Discord.
// Wymaga zmiennych DISCORD_CLIENT_ID i DISCORD_CLIENT_SECRET w ustawieniach Vercel.
import crypto from 'node:crypto';
import { przekieruj, bezpiecznyPowrot, ciasteczko, zapakuj, STAN } from '../lib/sesja.js';

const obsluga = async (req) => {
  const url = new URL(req.url);
  const tryb = url.searchParams.get('tryb') === 'polacz' ? 'polacz' : 'logowanie';
  const wroc = bezpiecznyPowrot(url.searchParams.get('wroc'), tryb === 'polacz' ? '/ustawienia.html' : '/');
  const klient = process.env['DISCORD_CLIENT_ID'];
  if (!klient || !process.env['DISCORD_CLIENT_SECRET']) {
    return przekieruj((tryb === 'polacz' ? wroc : '/logowanie.html') + '?komunikat=discord-wylaczony');
  }
  const stan = crypto.randomBytes(16).toString('base64url');
  const p = new URLSearchParams({
    client_id: klient,
    response_type: 'code',
    redirect_uri: url.origin + '/api/discord-zwrot',
    scope: 'identify',
    state: stan,
    prompt: 'none'
  });
  return przekieruj('https://discord.com/oauth2/authorize?' + p.toString(),
    ciasteczko(STAN, zapakuj({ stan, tryb, wroc }, 600), 600));
};

export default { fetch: obsluga };
