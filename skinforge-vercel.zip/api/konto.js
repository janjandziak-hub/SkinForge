// /api/konto – zmiany na koncie zalogowanego użytkownika.
// akcja: profil (nick, e-mail), haslo (ustawienie lub zmiana), rozlacz (steam/discord),
// wyloguj-wszedzie, usun (usunięcie konta).
import {
  biezacy, publiczne, zapiszKonto, kontoPoEmailu, normalizujEmail, poprawnyEmail, oczyscNick,
  bladHasla, sprawdzHaslo, hashHasla, zmienEmail, odlaczSerwis, sposobyLogowania, usunKonto,
  zTejStrony, wczytajJson, blad
} from '../lib/konta.js';
import { json, ciasteczkoSesji, usunSesje } from '../lib/sesja.js';

const obsluga = async (req) => {
  if (req.method !== 'POST') return blad('Zła metoda', 405);
  if (!zTejStrony(req)) return blad('Niedozwolone źródło żądania', 403);
  const k = await biezacy(req);
  if (!k) return blad('Nie jesteś zalogowany.', 401);
  const d = await wczytajJson(req);

  switch (d.akcja) {
    case 'profil': {
      const nick = oczyscNick(d.nick);
      if (nick.length < 3) return blad('Nick musi mieć co najmniej 3 znaki.');
      const email = d.email ? normalizujEmail(d.email) : null;
      if (email && !poprawnyEmail(email)) return blad('Podaj poprawny adres e-mail.');
      if (!email && k.haslo) return blad('Konto z hasłem musi mieć adres e-mail.');
      if (email !== k.email) {
        if (email && await kontoPoEmailu(email)) return blad('Ten adres e-mail jest już używany przez inne konto.');
        await zmienEmail(k, email);
      }
      k.nick = nick;
      await zapiszKonto(k);
      return json({ ok: true, uzytkownik: publiczne(k) });
    }
    case 'haslo': {
      if (k.haslo && !sprawdzHaslo(String(d.stare || ''), k.haslo)) return blad('Obecne hasło jest nieprawidłowe.', 401);
      const bh = bladHasla(d.nowe);
      if (bh) return blad(bh);
      if (!k.email) return blad('Najpierw dodaj adres e-mail w profilu. Będziesz się nim logować razem z hasłem.');
      k.haslo = hashHasla(d.nowe);
      k.sv = (k.sv || 0) + 1; // wylogowuje inne urządzenia
      await zapiszKonto(k);
      return json({ ok: true, uzytkownik: publiczne(k) }, 200, ciasteczkoSesji(k));
    }
    case 'rozlacz': {
      const s = d.serwis;
      if (s !== 'steam' && s !== 'discord') return blad('Nieznany serwis.');
      if (sposobyLogowania(k, s) === 0) {
        return blad('To jedyny sposób logowania na to konto. Najpierw ustaw e-mail i hasło albo połącz inne konto.');
      }
      await odlaczSerwis(k, s);
      return json({ ok: true, uzytkownik: publiczne(k) });
    }
    case 'wyloguj-wszedzie': {
      k.sv = (k.sv || 0) + 1;
      await zapiszKonto(k);
      return json({ ok: true }, 200, usunSesje());
    }
    case 'usun': {
      if (d.potwierdzenie !== 'USUŃ') return blad('Wpisz USUŃ, żeby potwierdzić.');
      if (k.haslo && !sprawdzHaslo(String(d.haslo || ''), k.haslo)) return blad('Hasło jest nieprawidłowe.', 401);
      await usunKonto(k);
      return json({ ok: true }, 200, usunSesje());
    }
    default:
      return blad('Nieznana akcja.');
  }
};

export default { fetch: obsluga };
