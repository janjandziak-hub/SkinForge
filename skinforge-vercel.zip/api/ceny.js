// /api/ceny – najniższe ceny skinów CS2 w złotówkach z publicznego API Skinport.
// Odpowiedź jest trzymana w pamięci podręcznej Vercel przez 10 minut,
// więc Skinport dostaje najwyżej kilka zapytań na godzinę.

const SKINPORT_URL = 'https://api.skinport.com/v1/items?app_id=730&currency=PLN&tradable=0';
const SKIP = /^(Sticker|Patch|Graffiti|Sealed Graffiti|Music Kit|Charm|Souvenir Charm) \|/;

let memo = null; // { at, body }

const odpowiedz = (body, cache) => new Response(body, {
  headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': cache
  }
});

const obsluga = async () => {
  try {
    if (!memo || Date.now() - memo.at > 5 * 60 * 1000) {
      const r = await fetch(SKINPORT_URL, { headers: { 'Accept-Encoding': 'br' } });
      if (!r.ok) throw new Error('Skinport HTTP ' + r.status);
      const list = await r.json();

      // nazwa -> [najniższa cena, liczba ofert]
      const p = {};
      for (const it of list) {
        const name = it.market_hash_name;
        if (!name || SKIP.test(name)) continue;
        const price = it.min_price != null ? it.min_price : it.suggested_price;
        if (price == null) continue;
        const q = it.quantity || 0;
        const prev = p[name];
        if (!prev) p[name] = [price, q];
        else { prev[0] = Math.min(prev[0], price); prev[1] += q; }
      }
      memo = { at: Date.now(), body: JSON.stringify({ updated: new Date().toISOString(), currency: 'PLN', p }) };
    }
    return odpowiedz(memo.body, 'public, max-age=60, s-maxage=600, stale-while-revalidate=3600');
  } catch (e) {
    console.error('Ceny Skinport:', e.message);
    if (memo) return odpowiedz(memo.body, 'public, max-age=30, s-maxage=60');
    return new Response(JSON.stringify({ error: 'Nie udało się pobrać cen', detail: String(e.message || e) }), {
      status: 502, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }
    });
  }
};

export default { fetch: obsluga };
