// /api/logowanie – logowanie e-mailem i hasłem.
import { kontoPoEmailu, sprawdzHaslo, normalizujEmail, zablokowany, nieudanaProba, wyczyscProby, zTejStrony, wczytajJson, publiczne, blad } from '../lib/konta.js';
import { json, ciasteczkoSesji } from '../lib/sesja.js';

const obsluga = async (req) => {
  if (req.method !== 'POST') return blad('Zła metoda', 405);
  if (!zTejStrony(req)) return blad('Niedozwolone źródło żądania', 403);
  const d = await wczytajJson(req);
  const email = normalizujEmail(d.email);
  if (!email || typeof d.haslo !== 'string') return blad('Podaj e-mail i hasło.');
  if (await zablokowany(email)) return blad('Za dużo nieudanych prób. Spróbuj ponownie za 15 minut.', 429);
  const k = await kontoPoEmailu(email);
  if (!k || !sprawdzHaslo(d.haslo, k.haslo)) {
    await nieudanaProba(email);
    return blad('Nieprawidłowy e-mail lub hasło.', 401);
  }
  await wyczyscProby(email);
  return json({ ok: true, uzytkownik: publiczne(k) }, 200, ciasteczkoSesji(k));
};

export default { fetch: obsluga };
