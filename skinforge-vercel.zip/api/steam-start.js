// /api/steam-start?tryb=logowanie|polacz&wroc=/sciezka – przekierowanie na logowanie Steam.
import { przekieruj, bezpiecznyPowrot } from '../lib/sesja.js';

const obsluga = async (req) => {
  const url = new URL(req.url);
  const strona = url.origin;
  const tryb = url.searchParams.get('tryb') === 'polacz' ? 'polacz' : 'logowanie';
  const wroc = bezpiecznyPowrot(url.searchParams.get('wroc'), tryb === 'polacz' ? '/ustawienia.html' : '/');
  const powrot = strona + '/api/steam-zwrot?tryb=' + tryb + '&wroc=' + encodeURIComponent(wroc);
  const p = new URLSearchParams({
    'openid.ns': 'http://specs.openid.net/auth/2.0',
    'openid.mode': 'checkid_setup',
    'openid.return_to': powrot,
    'openid.realm': strona + '/',
    'openid.identity': 'http://specs.openid.net/auth/2.0/identifier_select',
    'openid.claimed_id': 'http://specs.openid.net/auth/2.0/identifier_select'
  });
  return przekieruj('https://steamcommunity.com/openid/login?' + p.toString());
};

export default { fetch: obsluga };
