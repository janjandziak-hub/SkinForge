// /api/ja – dane zalogowanego użytkownika (albo informacja, że nikt nie jest zalogowany).
import { biezacy, publiczne, discordWlaczony } from '../lib/konta.js';
import { json, usunSesje } from '../lib/sesja.js';

const obsluga = async (req) => {
  try {
    const k = await biezacy(req);
    const uslugi = { discord: discordWlaczony() };
    if (!k) return json({ zalogowany: false, uslugi });
    return json({ ...publiczne(k), uslugi });
  } catch (e) {
    console.error('ja:', e.message);
    return json({ zalogowany: false, blad: 'Błąd serwera' }, 500, usunSesje());
  }
};

export default { fetch: obsluga };
