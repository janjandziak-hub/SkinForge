// /api/rejestracja – zakłada konto na e-mail i hasło i od razu loguje.
import { utworzKonto, kontoPoEmailu, normalizujEmail, poprawnyEmail, bladHasla, oczyscNick, zTejStrony, wczytajJson, publiczne, blad } from '../lib/konta.js';
import { json, ciasteczkoSesji } from '../lib/sesja.js';

const obsluga = async (req) => {
  if (req.method !== 'POST') return blad('Zła metoda', 405);
  if (!zTejStrony(req)) return blad('Niedozwolone źródło żądania', 403);
  const d = await wczytajJson(req);
  const email = normalizujEmail(d.email);
  const nick = oczyscNick(d.nick);
  if (!poprawnyEmail(email)) return blad('Podaj poprawny adres e-mail.');
  if (nick.length < 3) return blad('Nick musi mieć co najmniej 3 znaki.');
  const bh = bladHasla(d.haslo);
  if (bh) return blad(bh);
  if (!d.zgoda) return blad('Zaakceptuj regulamin i politykę prywatności.');
  if (await kontoPoEmailu(email)) return blad('Konto z tym adresem e-mail już istnieje. Zaloguj się.');
  const k = await utworzKonto({ email, haslo: d.haslo, nick });
  return json({ ok: true, uzytkownik: publiczne(k) }, 200, ciasteczkoSesji(k));
};

export default { fetch: obsluga };
