// /api/discord-zwrot – Discord wraca tutaj po zalogowaniu.
// Tryb "polacz": dołącza konto Discord do zalogowanego konta SkinForge.
// Tryb "logowanie": loguje na konto połączone z tym Discordem albo zakłada nowe.
import { biezacy, kontoPoSerwisie, utworzKonto, polaczSerwis } from '../lib/konta.js';
import { przekieruj, ciasteczkoSesji, rozpakuj, ciasteczko, STAN } from '../lib/sesja.js';

const zKomunikatem = (wroc, wartosc) => wroc + (wroc.includes('?') ? '&' : '?') + 'komunikat=' + wartosc;

const obsluga = async (req) => {
  const url = new URL(req.url);
  const s = rozpakuj(req, STAN);
  const czyscStan = ciasteczko(STAN, '', 0);
  const tryb = s && s.tryb === 'polacz' ? 'polacz' : 'logowanie';
  const wroc = (s && s.wroc) || (tryb === 'polacz' ? '/ustawienia.html' : '/');
  const bladStrona = tryb === 'polacz' ? wroc : '/logowanie.html';
  try {
    if (url.searchParams.get('error')) return przekieruj(zKomunikatem(bladStrona, 'anulowano'), czyscStan);
    if (!s || url.searchParams.get('state') !== s.stan) throw new Error('Nieprawidłowy stan logowania');
    const kod = url.searchParams.get('code');
    if (!kod) throw new Error('Brak kodu');

    const t = await fetch('https://discord.com/api/oauth2/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: process.env['DISCORD_CLIENT_ID'],
        client_secret: process.env['DISCORD_CLIENT_SECRET'],
        grant_type: 'authorization_code',
        code: kod,
        redirect_uri: url.origin + '/api/discord-zwrot'
      }).toString()
    });
    if (!t.ok) throw new Error('Discord token HTTP ' + t.status);
    const token = (await t.json()).access_token;
    const u = await fetch('https://discord.com/api/users/@me', { headers: { Authorization: 'Bearer ' + token } });
    if (!u.ok) throw new Error('Discord profil HTTP ' + u.status);
    const p = await u.json();
    const discord = {
      id: String(p.id),
      nazwa: p.username,
      nick: p.global_name || p.username,
      awatar: p.avatar ? 'https://cdn.discordapp.com/avatars/' + p.id + '/' + p.avatar + '.png?size=128' : ''
    };

    const wlasciciel = await kontoPoSerwisie('discord', discord.id);
    if (tryb === 'polacz') {
      const k = await biezacy(req);
      if (!k) return przekieruj('/logowanie.html?komunikat=zaloguj', czyscStan);
      if (wlasciciel && wlasciciel.id !== k.id) return przekieruj(zKomunikatem(wroc, 'discord-zajety'), czyscStan);
      await polaczSerwis(k, 'discord', discord);
      return przekieruj(zKomunikatem(wroc, 'discord-polaczony'), czyscStan);
    }

    let k = wlasciciel;
    if (k) await polaczSerwis(k, 'discord', discord);
    else k = await utworzKonto({ nick: discord.nick, discord });
    return przekieruj(wroc, ciasteczkoSesji(k), czyscStan);
  } catch (e) {
    console.error('Discord:', e.message);
    return przekieruj(zKomunikatem(bladStrona, 'blad'), czyscStan);
  }
};

export default { fetch: obsluga };
