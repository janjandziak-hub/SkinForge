// /api/steam-zwrot – Steam wraca tutaj po zalogowaniu.
// Tryb "polacz": dołącza konto Steam do zalogowanego konta SkinForge.
// Tryb "logowanie": loguje na konto połączone z tym Steamem albo zakłada nowe.
import { biezacy, kontoPoSerwisie, utworzKonto, polaczSerwis } from '../lib/konta.js';
import { przekieruj, ciasteczkoSesji, bezpiecznyPowrot } from '../lib/sesja.js';

function cdata(xml, tag) {
  const m = xml.match(new RegExp('<' + tag + '><!\\[CDATA\\[([\\s\\S]*?)\\]\\]></' + tag + '>'));
  return m ? m[1] : '';
}
const zKomunikatem = (wroc, klucz, wartosc) => wroc + (wroc.includes('?') ? '&' : '?') + klucz + '=' + wartosc;

const obsluga = async (req) => {
  const url = new URL(req.url);
  const q = url.searchParams;
  const strona = url.origin;
  const tryb = q.get('tryb') === 'polacz' ? 'polacz' : 'logowanie';
  const wroc = bezpiecznyPowrot(q.get('wroc'), tryb === 'polacz' ? '/ustawienia.html' : '/');
  const bladStrona = tryb === 'polacz' ? wroc : '/logowanie.html';
  try {
    if (q.get('openid.mode') !== 'id_res') return przekieruj(zKomunikatem(bladStrona, 'komunikat', 'anulowano'));
    if (!(q.get('openid.return_to') || '').startsWith(strona + '/api/steam-zwrot')) throw new Error('Zły adres powrotu');
    if (q.get('openid.op_endpoint') !== 'https://steamcommunity.com/openid/login') throw new Error('Zły dostawca logowania');
    const m = (q.get('openid.claimed_id') || '').match(/^https:\/\/steamcommunity\.com\/openid\/id\/(\d{17})$/);
    if (!m) throw new Error('Brak identyfikatora Steam');
    const steamId = m[1];

    // Potwierdzenie u Steama, że odpowiedź jest prawdziwa
    const spr = new URLSearchParams();
    for (const [k, v] of q) if (k.startsWith('openid.')) spr.set(k, v);
    spr.set('openid.mode', 'check_authentication');
    const r = await fetch('https://steamcommunity.com/openid/login', {
      method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: spr.toString()
    });
    if (!/is_valid\s*:\s*true/.test(await r.text())) throw new Error('Steam nie potwierdził logowania');

    let nick = '', awatar = '';
    try {
      const xml = await (await fetch('https://steamcommunity.com/profiles/' + steamId + '/?xml=1')).text();
      nick = cdata(xml, 'steamID'); awatar = cdata(xml, 'avatarMedium');
    } catch (e) { /* profil prywatny – zostaje sam SteamID */ }
    const steam = { id: steamId, nick: nick || 'Steam ' + steamId.slice(-4), awatar };

    const wlasciciel = await kontoPoSerwisie('steam', steamId);
    if (tryb === 'polacz') {
      const k = await biezacy(req);
      if (!k) return przekieruj('/logowanie.html?komunikat=zaloguj');
      if (wlasciciel && wlasciciel.id !== k.id) return przekieruj(zKomunikatem(wroc, 'komunikat', 'steam-zajety'));
      await polaczSerwis(k, 'steam', steam);
      return przekieruj(zKomunikatem(wroc, 'komunikat', 'steam-polaczony'));
    }

    let k = wlasciciel;
    if (k) await polaczSerwis(k, "steam", steam);
    else k = await utworzKonto({ nick: steam.nick, steam });
    return przekieruj(wroc, ciasteczkoSesji(k));
  } catch (e) {
    console.error('Steam:', e.message);
    return przekieruj(zKomunikatem(bladStrona, 'komunikat', 'blad'));
  }
};

export default { fetch: obsluga };
