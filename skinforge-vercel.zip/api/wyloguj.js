// /api/wyloguj – usuwa ciasteczko sesji i wraca na stronę główną.
import { przekieruj, usunSesje } from '../lib/sesja.js';

const obsluga = async () => przekieruj('/', usunSesje());

export default { fetch: obsluga };
